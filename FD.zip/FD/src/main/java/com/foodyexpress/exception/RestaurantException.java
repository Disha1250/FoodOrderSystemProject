package com.foodyexpress.exception;

public class RestaurantException extends Exception {

	public RestaurantException() {
		// TODO Auto-generated constructor stub
	}

	public RestaurantException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
