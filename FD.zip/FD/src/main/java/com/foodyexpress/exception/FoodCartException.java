package com.foodyexpress.exception;

public class FoodCartException extends Exception {

	public FoodCartException() {
		// TODO Auto-generated constructor stub
	}

	public FoodCartException(String message) {
		// TODO Auto-generated constructor stub
		super(message);
	}

}
