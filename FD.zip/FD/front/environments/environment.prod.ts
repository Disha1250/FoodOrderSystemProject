export const environment = {
  production: true,
  BASE_URL: "https://full-stack-backend.herokuapp.com/api",
  CHAT_SOCKET_API: 'https://full-stack-backend.herokuapp.com/chat',
  CART_SOCKET_API: 'https://full-stack-backend.herokuapp.com/cart'
};
