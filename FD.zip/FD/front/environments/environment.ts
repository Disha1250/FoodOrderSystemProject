export const environment = {
  production: false,
  BASE_URL: 'http://localhost:4000/api',
  CHAT_SOCKET_API: 'http://localhost:4000/chat',
  CART_SOCKET_API: 'http://localhost:4000/cart'
};
