export class User {
  firstName!: string
  lastName!: string
  username!: string
  password!: string
  confirmPassword!: string
  address!: string
  email!: string
  phoneNumber!: string
}
